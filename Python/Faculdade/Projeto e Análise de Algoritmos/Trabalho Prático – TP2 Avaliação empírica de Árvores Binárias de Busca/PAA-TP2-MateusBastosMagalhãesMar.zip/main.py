from avl import *
from rb import *
import time

if __name__ == "__main__":
    try:
        tree_type = input("Digite o tipo de árvore a ser criada (para AVL digite 0, para Vermelho e Preto digite 1): ").lower()
        n = int(input("Digite o valor de n para criar a árvore: "))

        if tree_type == "0":
            start_time = time.time()

            avl_tree = AVLTree()
            avl_tree.create_random_avl_tree(n)

            execution_time = time.time() - start_time
            print(f"Tempo de execução: {execution_time:.6f} segundos")

            print("Árvore AVL criada com sucesso!")
        elif tree_type == "1":
            start_time = time.time()

            rb_tree = RedBlackTree()
            rb_tree.create_random_rb_tree(n)

            execution_time = time.time() - start_time
            print(f"Tempo de execução: {execution_time:.6f} segundos")

            print("Árvore Vermelho e Preto criada com sucesso!")
        else:
            print("Tipo de árvore inválido. Escolha entre AVL ou Vermelho e Preto.")
    except ValueError:
        print("Por favor, insira um valor inteiro válido para n.")

    while True:
        try:
            print("\nOpções:")
            print("1. Terminar a execução do programa")
            print("2. Buscar um elemento da árvore")
            print("3. Remover um elemento da árvore")

            choice = input("Escolha uma opção (1, 2 ou 3): ")

            if choice == "1":
                print("Encerrando a execução.")
                break
            elif choice == "2":
                element_to_search = int(input("Digite o elemento a ser buscado: "))
                if tree_type == "0":
                    start_time = time.time()

                    result = avl_tree.search(element_to_search)

                    execution_time = time.time() - start_time
                    print(f"Tempo de execução: {execution_time:.6f} segundos")
                elif tree_type == "1":
                    start_time = time.time()

                    result = rb_tree.search(element_to_search)

                    execution_time = time.time() - start_time
                    print(f"Tempo de execução: {execution_time:.6f} segundos")
                if result:
                    print(f"Elemento {element_to_search} encontrado na árvore.")
                else:
                    print(f"Elemento {element_to_search} não encontrado na árvore.")

            elif choice == "3":
                element_to_remove = int(input("Digite o elemento a ser removido: "))
                if tree_type == "0":

                    start_time = time.time()

                    if avl_tree.search(element_to_remove):
                        avl_tree.delete(element_to_remove)
                        print(f"Elemento {element_to_remove} removido da árvore AVL.")

                    else:
                        print(f"Elemento {element_to_remove} não encontrado na árvore AVL.")

                    execution_time = time.time() - start_time
                    print(f"Tempo de execução: {execution_time:.6f} segundos")

                elif tree_type == "1":

                    start_time = time.time()

                    if rb_tree.search(element_to_remove):
                        rb_tree.delete(element_to_remove)
                        print(f"Elemento {element_to_remove} removido da árvore Vermelho e Preto.")

                    else:
                        print(f"Elemento {element_to_remove} não encontrado na árvore Vermelho e Preto.")

                    execution_time = time.time() - start_time
                    print(f"Tempo de execução: {execution_time:.6f} segundos")
            else:
                print("Opção inválida. Escolha entre 1, 2 ou 3.")
        except ValueError:
            print("Por favor, insira uma opção válida.")
