#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "merge.h"
#include "heap.h"
#include "quick.h"

// Função para gerar um array de inteiros aleatórios
void geraArrayAleatorio(int *array, int tamanho) {
    for (int i = 0; i < tamanho; i++) {
        array[i] = rand() % 65536; // Números entre 0 e 65535
    }
}


int main() {
    int tamanho; // Exemplo de tamanho de entrada

    printf("Digite o tamanho do vetor: ");
    scanf("%d", &tamanho);

    int *array = malloc(tamanho * sizeof(int));
    int *copiaMergesort = malloc(tamanho * sizeof(int));
    int *copiaHeapsort = malloc(tamanho * sizeof(int));
    int *copiaQuicksort = malloc(tamanho * sizeof(int));

    // Geração do array aleatório
    geraArrayAleatorio(array, tamanho);

    // Copia o vetor original para as cópias
    memcpy(copiaMergesort, array, tamanho * sizeof(int));
    memcpy(copiaHeapsort, array, tamanho * sizeof(int));
    memcpy(copiaQuicksort, array, tamanho * sizeof(int));

    /*
    // Imprime o vetor gerado
    printf("Vetor gerado:\n");
    for (int i = 0; i < tamanho; i++) {
        printf("%d ", array[i]);
    }
    printf("\n");
     */


    // Medição do tempo de execução do Mergesort
    clock_t inicioMergesort = clock();
    mergesort(copiaMergesort, 0, tamanho - 1);
    clock_t fimMergesort = clock();
    double tempoMergesort = (double)(fimMergesort - inicioMergesort) / CLOCKS_PER_SEC;
    printf("Tempo de execução do Mergesort: %.6f segundos\n", tempoMergesort);

    // Medição do tempo de execução do Heapsort
    clock_t inicioHeapsort = clock();
    heapsort(copiaHeapsort, tamanho);
    clock_t fimHeapsort = clock();
    double tempoHeapsort = (double)(fimHeapsort - inicioHeapsort) / CLOCKS_PER_SEC;
    printf("Tempo de execução do Heapsort: %.6f segundos\n", tempoHeapsort);

    // Medição do tempo de execução do Quicksort
    clock_t inicioQuicksort = clock();
    quicksort(copiaQuicksort, 0, tamanho - 1);
    clock_t fimQuicksort = clock();
    double tempoQuicksort = (double)(fimQuicksort - inicioQuicksort) / CLOCKS_PER_SEC;
    printf("Tempo de execução do Quicksort: %.6f segundos\n", tempoQuicksort);

 
    free(array);
    free(copiaMergesort);
    free(copiaHeapsort);
    free(copiaQuicksort);
    return 0;
}
