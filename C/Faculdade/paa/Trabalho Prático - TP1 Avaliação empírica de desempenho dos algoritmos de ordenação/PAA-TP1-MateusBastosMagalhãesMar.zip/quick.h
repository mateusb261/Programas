#include <stdio.h>

int partition(int *array, int baixo, int alto) {
    int pivo = array[alto];
    int i = (baixo - 1);

    for (int j = baixo; j <= alto - 1; j++) {
        if (array[j] < pivo) {
            i++;
            int temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }
    }

    int temp = array[i + 1];
    array[i + 1] = array[alto];
    array[alto] = temp;

    return (i + 1);
}

void quicksort(int *array, int baixo, int alto) {
    if (baixo < alto) {
        int pi = partition(array, baixo, alto);
        quicksort(array, baixo, pi - 1);
        quicksort(array, pi + 1, alto);
    }
}