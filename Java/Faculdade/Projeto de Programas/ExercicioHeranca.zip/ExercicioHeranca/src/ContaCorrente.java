public class ContaCorrente extends ContaBancaria {

	final static double LIMITE = 500;

	public ContaCorrente(int numero, double saldo) {
		super(numero, saldo);
	}

	//metodos
	boolean sacar(double quantidade) {
		if (this.LIMITE < this.getSaldo()) {
			return true;
		}
		else {
			return false;
		}
	}
}
