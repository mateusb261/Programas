
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class ProgramaBanco {

	 private static ArrayList<ContaCorrente> contasCorrente; 
	 private static ArrayList<ContaPoupanca> contasPoupanca; 
	
	public static  void criarContaCorrente(){
		// criando a Conta Corrente
		ContaCorrente minhaConta;
		String entrada;

		entrada=JOptionPane.showInputDialog("Digite o n�mero da conta corrente:");
		int numeroConta = Integer.parseInt(entrada);

		entrada=JOptionPane.showInputDialog("Digite o valor inicial:");
		double valorConta = Double.parseDouble(entrada);

		minhaConta = new ContaCorrente(numeroConta, valorConta);

		JOptionPane.showMessageDialog(null,"O valor atual do saldo da conta: "+minhaConta.getNumero()+" � "+minhaConta.getSaldo());
		entrada=JOptionPane.showInputDialog("Depositar um valor");
		double valor = Double.parseDouble(entrada);
		minhaConta.depositar(valor);
		JOptionPane.showMessageDialog(null,"O valor atual do saldo da conta: "+minhaConta.getNumero()+" � "+minhaConta.getSaldo());
		
		contasCorrente.add(minhaConta);
	}
	
	
	public static void criarContaPoupanca(){
		// criando a Conta Poupan�a
		ContaPoupanca minhaPoupanca;
		String entrada;
		
		entrada=JOptionPane.showInputDialog("Digite o n�mero da conta poupan�a:");
		int numeroPoupanca = Integer.parseInt(entrada);

		entrada=JOptionPane.showInputDialog("Digite o valor inicial:");
		double valorPoupanca = Double.parseDouble(entrada);
		
		minhaPoupanca = new ContaPoupanca(numeroPoupanca,valorPoupanca);
		JOptionPane.showMessageDialog(null,"O saldo da poupanca: "+minhaPoupanca.getNumero()+" � "+minhaPoupanca.getSaldo());

		entrada=JOptionPane.showInputDialog("Digite o valor para deposito na poupan�a");
		Double valor = Double.parseDouble(entrada);
		minhaPoupanca.depositar(valor);
		JOptionPane.showMessageDialog(null,"O saldo da poupanca: "+minhaPoupanca.getNumero()+" � "+minhaPoupanca.getSaldo());
		JOptionPane.showMessageDialog(null,"O valor atual do rendimento da poupan�a: "+minhaPoupanca.getNumero()+" � "+minhaPoupanca.getRendimento()+" reais");
		contasPoupanca.add(minhaPoupanca);

	}
	
	public static void listarContasCorrente(){
		String retorno = "\t<< Lista de Contas Corrente >>\n";
		for(int i=0;i<contasCorrente.size();i++){
			retorno+="N�mero:"+contasCorrente.get(i).getNumero()+"\n"+
					"Saldo:"+contasCorrente.get(i).getSaldo()+"\n"+
					"-----------------------------------------\n";
		}
		JOptionPane.showMessageDialog(null,retorno);

	}
	
	public static void listarContasPoupanca(){
		String retorno = "\t<< Lista de Contas Poupan�a >>\n";
		for(int i=0;i<contasPoupanca.size();i++){
			retorno+="N�mero:"+contasPoupanca.get(i).getNumero()+"\n"+
					"Saldo:"+contasPoupanca.get(i).getSaldo()+"\n"+
					"Rendimento:"+contasPoupanca.get(i).getRendimento()+"\n"+
					"-----------------------------------------\n";
		}
		JOptionPane.showMessageDialog(null,retorno);

	}
	
	public static void main(String[] args) {
		
		String operacao;
		
		contasCorrente = new ArrayList<ContaCorrente>();
		contasPoupanca = new ArrayList<ContaPoupanca>();
		
		do{
			 operacao = JOptionPane.showInputDialog(null, "####### Banco UEA ####### \n \t\t Informe a opera��o: \n [C] Gerenciar Conta Corrente \n [P] Gerenciar Poupan�a\n [L] Listar Contas Corrente \n [M] Lista Contas Poupan�a \n [F] fim\n");
						
			if (operacao.charAt(0) == 'c'){
				criarContaCorrente();
				
			}else if (operacao.charAt(0) == 'p'){
				criarContaPoupanca();
				
			}else if (operacao.charAt(0) == 'l'){
				listarContasCorrente();
				
			}else if (operacao.charAt(0) == 'm'){
				listarContasPoupanca();
				
			}
			
		}while(operacao.charAt(0)!= 'f');
		System.exit(0);
		
		
		
	}
}
