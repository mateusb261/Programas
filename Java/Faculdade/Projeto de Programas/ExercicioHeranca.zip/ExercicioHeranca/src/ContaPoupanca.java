
public class ContaPoupanca extends ContaBancaria {
	double rendimento;
	final static double JUROS = 0.10;

	public ContaPoupanca(int numero, double saldo) {	
		super(numero,saldo);
	}
	
	public double getRendimento() {
		return this.getSaldo()*JUROS;
	}

	public void setRendimento(double rendimento) {
		this.rendimento = rendimento;
	}
}

