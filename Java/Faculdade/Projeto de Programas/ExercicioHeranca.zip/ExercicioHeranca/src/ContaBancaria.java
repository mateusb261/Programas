
public class ContaBancaria {

	//atributos
	private int numero;
	private double saldo;
	
	//contrutor
	public ContaBancaria(int numero, double saldo){
		this.numero=numero;
		this.saldo=saldo;
	}
	
	public ContaBancaria(int numero){
		this.numero=numero;
		this.saldo=saldo;
	}
	
	//metodos
	boolean sacar(double quantidade) {
	if (this.saldo < quantidade) {
		return false;
	}
	 else {
			this.saldo = this.saldo - quantidade;
			return true;
	  }

	}
	
	void depositar(double quantidade) {
		this.saldo = saldo + quantidade;
	}
	public double getSaldo() {
		return saldo;
	}
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	boolean transferePara(ContaBancaria destino, double valor) {
		boolean retirou = this.sacar(valor);
		if (retirou == false) {
			// n�o deu pra sacar!
			return false;
		}
		else {
			destino.depositar(valor);
			return true;
		}

	}
}
