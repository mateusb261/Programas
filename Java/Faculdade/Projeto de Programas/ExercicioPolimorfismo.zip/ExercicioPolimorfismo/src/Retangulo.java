
public class Retangulo extends FiguraGeometrica {

	//Polimorfismo de Sobrecarga (Overload)
	public Retangulo() {
	}

	public Retangulo(float base, float altura) {
		super(base, altura);
	}
		
	//Polimorfismo de Sobreescrita (Override)
	 public void calcularArea(float base, float altura){
		 super.setArea(base * altura);
		
	}
	 
	 public void calcularArea(){
		 super.setArea(super.getBase()*super.getAltura());
		
	}

}
