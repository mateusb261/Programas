
public class Principal {

	public static void main(String[] args) {
		
		Triangulo triangulo1 = new Triangulo(10,5);
		triangulo1.calcularArea();
		System.out.printf("Exemplo 1 - A area do Triangulo = %.2f",triangulo1.getArea());
		System.out.println("");
		triangulo1.calcularArea(50,20);
		System.out.printf("Exemplo 2 - A area do Triangulo = %.2f",triangulo1.getArea());
		System.out.println("");		
		Retangulo retangulo = new Retangulo(10,5);
		retangulo.calcularArea();
		System.out.printf("Exemplo 3 - A area do Retangulo = %.2f",retangulo.getArea());
		System.out.println("");
		retangulo.calcularArea(50,20);
		System.out.printf("Exemplo 4 - A area do Retangulo = %.2f",retangulo.getArea());
		

	}

}
