
public class TrianguloEquilatero extends FiguraGeometrica {

	public TrianguloEquilatero() {
		// TODO Auto-generated constructor stub
	}

	public TrianguloEquilatero(float base, float altura) {
		super(base, altura);
		// TODO Auto-generated constructor stub
	}

}
