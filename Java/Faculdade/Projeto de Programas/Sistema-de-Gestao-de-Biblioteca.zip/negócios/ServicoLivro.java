package negócios;
import dados.Autor;
import dados.Editora;
import dados.Livro;

public abstract class ServicoLivro {

    public abstract void cadastrarLivro(String titulo, Autor autor, Editora editora);

    public abstract void atualizarLivro(String titulo, String novoTitulo, Autor novoAutor, Editora novaEditora);

    public abstract void removerLivro(String titulo);

    public abstract Livro buscarLivroPorTitulo(String titulo);

    // Outros métodos relacionados a livros podem ser declarados aqui
}
