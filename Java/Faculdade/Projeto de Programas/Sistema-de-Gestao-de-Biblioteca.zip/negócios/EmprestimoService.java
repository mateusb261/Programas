package Negocios;

public interface EmprestimoService {
  void emprestarLivro(Livro livro, String nomeUsuario);
  void devolverLivro(Livro livro, String nomeUsuario);
}
