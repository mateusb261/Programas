package negócios;

import dados.Autor;
import dados.Livro;
import java.util.ArrayList;

public class ImpleAutor extends ServicoAutor {
    private ArrayList<Autor> listaDeAutores;

    public ImpleAutor() {
        listaDeAutores = new ArrayList<>();
    }

    @Override
    public void cadastrarAutor(String nome, String nacionalidade) {
        Autor autor = new Autor(nome, nacionalidade);
        listaDeAutores.add(autor);
    }

    @Override
    public void atualizarAutor(int id, String novoNome, String novaNacionalidade) {
        Autor autor = buscarAutorPorId(id);

        if (autor != null) {
            autor.setNome(novoNome);
            autor.setNacionalidade(novaNacionalidade);
        } else {
            System.out.println("Autor não encontrado. Atualização não realizada.");
        }
    }

    @Override
    public void removerAutor(int id) {
        Autor autor = buscarAutorPorId(id);
        if (autor != null) {
            listaDeAutores.remove(autor);
        } else {
            System.out.println("Autor não encontrado. Remoção não realizada.");
        }
    }

    @Override
    public Autor buscarAutorPorId(int id) {
        for (Autor autor : listaDeAutores) {
            if (autor.getId() == id) {
                return autor;
            }
        }

        return null;
    }

    @Override
    public Autor buscarAutorPorNome(String nome) {
        for (Autor autor : listaDeAutores) {
            if (autor.getNome().equals(nome)) {
                return autor;
            }
        }

        return null;
    }

    @Override
    public ArrayList<Autor> listarAutores() {
        return listaDeAutores;
    }

    @Override
    public void adicionarLivroParaAutor(int idAutor, Livro livro) {
        Autor autor = buscarAutorPorId(idAutor);
        if (autor != null) {
            autor.adicionarLivro(livro);
            autor.saveLivroToFile(livro); // Salva o livro no arquivo de texto
        } else {
            System.out.println("Autor não encontrado. Livro não adicionado.");
        }
    }

    // Outros métodos relacionados a autores podem ser implementados aqui
}
