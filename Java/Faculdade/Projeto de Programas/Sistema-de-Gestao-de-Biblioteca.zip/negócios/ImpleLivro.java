package negócios;

import dados.Autor;
import dados.Editora;
import dados.Livro;
import java.util.ArrayList;

public class ImpleLivro extends ServicoLivro {
    private ArrayList<Livro> listaDeLivros;

    public ImpleLivro() {
        listaDeLivros = new ArrayList<>();
    }

    @Override
    public void cadastrarLivro(String titulo, Autor autor, Editora editora) {
        Livro livro = new Livro(titulo, autor, editora);
        listaDeLivros.add(livro);
        autor.adicionarLivro(livro);
        editora.adicionarLivro(livro);
    }

    @Override
    public void atualizarLivro(String titulo, String novoTitulo, Autor novoAutor, Editora novaEditora) {
        Livro livro = buscarLivroPorTitulo(titulo);
        if (livro != null) {
            livro.setTitulo(novoTitulo);
            livro.setAutor(novoAutor);
            livro.setEditora(novaEditora);
        } else {
            System.out.println("Livro não encontrado. Atualização não realizada.");
        }
    }

    @Override
    public void removerLivro(String titulo) {
        Livro livro = buscarLivroPorTitulo(titulo);
        if (livro != null) {
            listaDeLivros.remove(livro);
            livro.getAutor().getLivrosAutor().remove(livro);
            livro.getEditora().getLivrosEditora().remove(livro);
        } else {
            System.out.println("Livro não encontrado. Remoção não realizada.");
        }
    }

    @Override
    public Livro buscarLivroPorTitulo(String titulo) {
        for (Livro livro : listaDeLivros) {
            if (livro.getTitulo().equals(titulo)) {
                return livro;
            }
        }
        return null;
    }

    // Outros métodos relacionados a livros podem ser implementados aqui
}
