package negócios;

import java.util.ArrayList;

public class ImpleEditora {
    private ArrayList<dados.Editora> listaDeEditoras;

    public ImpleEditora() {
        listaDeEditoras = new ArrayList<>();
    }

    public void cadastrarEditora(String nome, String localizacao) {
        dados.Editora editora = new dados.Editora(nome, localizacao);
        listaDeEditoras.add(editora);
    }

    public void atualizarEditora(String nomeAntigo, String novoNome, String novaLocalizacao) {
        dados.Editora editora = buscarEditoraPorNome(nomeAntigo);

        if (editora != null) {
            editora.setNome(novoNome);
            editora.setLocalizacao(novaLocalizacao);
        } else {
            System.out.println("Editora não encontrada. Atualização não realizada.");
        }
    }

    public void removerEditora(String nome) {
        dados.Editora editora = buscarEditoraPorNome(nome);

        if (editora != null) {
            listaDeEditoras.remove(editora);
        } else {
            System.out.println("Editora não encontrada. Remoção não realizada.");
        }
    }

    public dados.Editora buscarEditoraPorNome(String nome) {
        for (dados.Editora editora : listaDeEditoras) {
            if (editora.getNome().equals(nome)) {
                return editora;
            }
        }

        return null;
    }

    // Outros métodos relacionados a editoras podem ser implementados aqui
}
