package negócios;

import dados.Autor;
import dados.Livro;
import java.util.ArrayList;

public abstract class ServicoAutor {

    public abstract void cadastrarAutor(String nome, String nacionalidade);

    public abstract void atualizarAutor(int id, String novoNome, String novaNacionalidade);

    public abstract void removerAutor(int id);

    public abstract Autor buscarAutorPorId(int id);

    public abstract Autor buscarAutorPorNome(String nome);

    public abstract ArrayList<Autor> listarAutores();

    public abstract void adicionarLivroParaAutor(int idAutor, Livro livro);

}

