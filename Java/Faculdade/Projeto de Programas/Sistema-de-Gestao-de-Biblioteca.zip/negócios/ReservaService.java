package Negocios;

public interface ReservaService {
  void fazerReserva(Livro livro, String nomeUsuario);
  boolean verificarDisponibilidade(Livro livro);
  void consultarReservasSolicitadas();
  void cancelarReserva(Livro livro, String nomeUsuario);
}
