package negocio;

import dados.Livro;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ImpleService implements ReservaService, EmprestimoService {
    private Map<Livro, List<String>> reservas;
    private Map<Livro, String> emprestimos;

    public ImpleService() {
        reservas = new HashMap<>();
        emprestimos = new HashMap<>();
    }

    // Implementação dos métodos da interface ReservaService
    @Override
    public void fazerReserva(Livro livro, String nomeUsuario) {
        if (verificarDisponibilidade(livro)) {
            List<String> listaReservas = reservas.getOrDefault(livro, new ArrayList<>());
            listaReservas.add(nomeUsuario);
            reservas.put(livro, listaReservas);
            System.out.println("Reserva efetuada com sucesso!");
        } else {
            System.out.println("Não foi possível efetuar a reserva. Livro indisponível.");
        }
    }

    @Override
    public boolean verificarDisponibilidade(Livro livro) {
        return !emprestimos.containsKey(livro);
    }

    @Override
    public void consultarReservasSolicitadas() {
        for (Map.Entry<Livro, List<String>> entry : reservas.entrySet()) {
            Livro livro = entry.getKey();
            List<String> listaReservas = entry.getValue();
            System.out.println("Livro: " + livro.getTitulo());
            System.out.println("Reservas solicitadas por:");
            for (String nomeUsuario : listaReservas) {
                System.out.println("- " + nomeUsuario);
            }
            System.out.println("----------");
        }
    }

    @Override
    public void cancelarReserva(Livro livro, String nomeUsuario) {
        List<String> listaReservas = reservas.getOrDefault(livro, new ArrayList<>());
        if (listaReservas.remove(nomeUsuario)) {
            reservas.put(livro, listaReservas);
            System.out.println("Reserva cancelada com sucesso!");
        } else {
            System.out.println("Você não tem uma reserva para este livro.");
        }
    }

    // Implementação dos métodos da interface EmprestimoService
    @Override
    public void emprestarLivro(Livro livro, String nomeUsuario) {
        if (verificarDisponibilidade(livro)) {
            emprestimos.put(livro, nomeUsuario);
            System.out.println("Empréstimo realizado com sucesso!");
        } else {
            System.out.println("Não foi possível efetuar o empréstimo. Livro indisponível.");
        }
    }

    @Override
    public void devolverLivro(Livro livro, String nomeUsuario) {
        String usuarioEmprestimo = emprestimos.get(livro);
        if (usuarioEmprestimo != null && usuarioEmprestimo.equals(nomeUsuario)) {
            emprestimos.remove(livro);
            System.out.println("Livro devolvido com sucesso!");
        } else {
            System.out.println("Você não tem este livro emprestado.");
        }
    }
}
