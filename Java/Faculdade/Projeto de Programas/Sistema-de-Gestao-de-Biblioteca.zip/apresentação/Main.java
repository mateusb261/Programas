package apresentação;

import dados.Autor;
import dados.Editora;
import dados.Livro;

public class Main {
    public static void main(String[] args) {
        Autor mateus = new Autor("Mateus", "Bras");
        Editora saraiva = new Editora("Saraiva", "Bras");
        Livro teste1 = new Livro("teste1", mateus, saraiva);

        saraiva.saveAutorToFile(mateus);
        saraiva.saveLivroToFile(teste1);

        mateus.saveLivroToFile(teste1);

        Autor marcos = new Autor("Marcos", "Bras");
        Editora moderna = new Editora("Moderna", "Bras");
        Livro teste2 = new Livro("teste2", marcos, moderna);

        moderna.saveAutorToFile(marcos);
        moderna.saveLivroToFile(teste2);

        marcos.saveLivroToFile(teste2);
    }
}