package dados;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class Editora {

  /* Atributos */

  private String nome;
  private String localizacao;
  private ArrayList<Livro> livrosEditora;
  private ArrayList<Autor> autoresEditora;

  private static final String LIVROS_EDITORAS = "Lista de livros das Editoras.txt";

  private static final String AUTORES_EDITORAS = "Lista de autores das Editoras.txt";

  private static int contador_livros = 0;

  private static int contador_autores = 0;


  /* Construtor */

  public Editora(String nome, String localizacao) {
    this.nome = nome;
    this.localizacao = localizacao;
    this.livrosEditora = new ArrayList<>();
    this.autoresEditora = new ArrayList<>();
  }


  /* Getters e setters */

  public String getNome() {
    return nome;
  }

  public void setNome(String nome) {
    this.nome = nome;
  }

  public String getLocalizacao(String localizacao) {
    return localizacao;
  }

  public void setLocalizacao(String localizacao) {
    this.localizacao = localizacao;
  }

  public ArrayList<Livro> getLivrosEditora() {
    return livrosEditora;
  }

  public ArrayList<Autor> getAutoresEditora() {
    return autoresEditora;
  }


  /* Outras funções */

  public void adicionarLivro(Livro livro) {
    livrosEditora.add(livro);
  }

  public Autor encontrarAutor(String tituloLivro) {
    for (Livro livro : livrosEditora) {
      if (livro.getTitulo().equals(tituloLivro)) {
        return livro.getAutor();
      }
    }
    // Exceçao
    return null;
  }

  public void saveLivroToFile(Livro livro) {
    try (PrintWriter writer = new PrintWriter(new FileWriter(LIVROS_EDITORAS, true))) {

      if (contador_livros == 0) {
        writer.println("Livros da editora " + nome + ":");
      }

      if (livrosEditora.isEmpty() && contador_livros > 0) {
        writer.println("");
        writer.println("");
        writer.println("Livros da editora " + nome + ":");
      }

      writer.println(livro.getTitulo());

      contador_livros++;

    } catch (IOException e) {
      System.err.println("Erro ao escrever no arquivo: " + e.getMessage());
    }
  }

  public void saveAutorToFile(Autor autor) {
    try (PrintWriter writer = new PrintWriter(new FileWriter(AUTORES_EDITORAS, true))) {

      if (contador_autores == 0) {
        writer.println("Autores da editora " + nome + ":");
      }

      if (autoresEditora.isEmpty() && contador_autores > 0) {
        writer.println("");
        writer.println("");
        writer.println("Autores da editora " + nome + ":");
      }

      writer.println(autor.getNome());

      contador_autores++;

    } catch (IOException e) {
      System.err.println("Erro ao escrever no arquivo: " + e.getMessage());
    }
  }
}