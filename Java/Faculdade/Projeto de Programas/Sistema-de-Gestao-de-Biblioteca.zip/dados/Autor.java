package dados;

import java.util.ArrayList;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Autor {

    /* Atributos */

    private static int contadorId = 0;
    private int id;
    private String nome;
    private String nacionalidade;
    private ArrayList<Livro> livrosAutor;
    private static ArrayList<Autor> listaDeAutores = new ArrayList<>();
    private static final String LIVROS_AUTORES = "Lista de livros dos autores.txt";
    private static int contador_livros = 0;

    /* Construtor */

    public Autor(String nome, String nacionalidade) {
        this.id = ++contadorId;
        this.nome = nome;
        this.nacionalidade = nacionalidade;
        this.livrosAutor = new ArrayList<>();
    }


    /* Getters e setters */

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;

    }

    public String getNacionalidade() {
        return nacionalidade;
    }

    public void setNacionalidade(String nacionalidade) {
        this.nacionalidade = nacionalidade;
    }

    public int getId() {
        return id;
    }

    public void setId(int novoId) {

        // Verifica se o novoId já está em uso por outro autor
        for (Autor autor : listaDeAutores) {
            if (autor.getId() == novoId) {
                System.out.println("ID já está em uso por outro autor. Não foi possível alterar o ID.");
                return;
            }
        }
        // Se não está em uso, pode-se alterar o ID
        id = novoId;
    }

    public ArrayList<Livro> getLivrosAutor() {
        return livrosAutor;
    }


    /* Outras funções */

    public void adicionarLivro(Livro livro) {
        livrosAutor.add(livro);
    }

    public void adicionarAutor(Autor autor) {
        listaDeAutores.add(autor);
    }

    public void saveLivroToFile(Livro livro) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(LIVROS_AUTORES, true))) {

            if (contador_livros == 0) {
                writer.println("Livros do autor " + nome + ":");
            }

            if (livrosAutor.isEmpty() && contador_livros > 0) {
                writer.println("");
                writer.println("");
                writer.println("Livros do autor " + nome + ":");
            }

            writer.println(livro.getTitulo());

            contador_livros++;
            }

        catch (IOException e) {
            System.err.println("Erro ao escrever no arquivo: " + e.getMessage());
        }
    }
}