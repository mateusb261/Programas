import React from "react";

const Frontend = () => {
  return (
    <main className="principal">
      <h2>Categoria Frontend</h2>
      <div className="card">
        <p>Conteúdo da Frontend Page</p>
      </div>
    </main>
  );
};

export default Frontend;