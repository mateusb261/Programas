import React from 'react'

const Programacao = () => {
  return (
    <main className='principal'>
        <h2>Categoria Programacao</h2>
        <div className='card'>
            <p>Conteudo da pagina Programacao</p>
        </div>
    </main>
  )
}

export default Programacao;