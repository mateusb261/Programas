import React from 'react'

const Design = () => {
  return (
    <main className='principal'>
        <h2> Categoria Design </h2>
        <div className='card'>
            <p> Conteúdo da Página Frontend </p>
        </div>
    </main>
  )
}
 export default Design;