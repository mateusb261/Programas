import React from "react";

const Home = () => {
  return (
    <main className="principal">
      <h2>Últimos lançamentos</h2>
      <div className="card">
        <p>Conteúdos da Home Page</p>
      </div>
    </main>
  );
};