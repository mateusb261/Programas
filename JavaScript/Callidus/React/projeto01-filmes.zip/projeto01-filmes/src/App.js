import React, { Component } from 'react';
import TabelaHead from "./components/tabelaHead";
import TabelaFoot from "./components/tabelaFoot";
import TabelaBody from "./components/tabelaBody";

class App extends Component {
  state = {
    filmes: [],
    filmesOriginais: [],
    filtro: ''
  };

  componentDidMount() {
    fetch("/api/livros.json")
      .then(response => response.json())
      .then(filmes => this.setState({ filmes, filmesOriginais: filmes }))
      .catch(function (error) {
        console.log("Erro na requisição");
      })
      .finally(function () {
        console.log("Sempre retorna");
      });
  }

  handleRemoverLinha = (id) => {
    const filmes = this.state.filmes.filter(f => f.id !== id);
    this.setState({ filmes });
  };

  handleOrdenarCrescente = (titulo) => {
    const filmes = this.state.filmes.sort((a, b) =>
      a.titulo < b.titulo ? -1 : 0
    );
    this.setState({ filmes });
  };

  handleOrdenarDecrescente = (titulo) => {
    const filmes = this.state.filmes.sort((a, b) =>
      a.titulo > b.titulo ? -1 : 0
    );
    this.setState({ filmes });
  };

  handleFiltrarFilmes = () => {
    const filtroMin = this.state.filtro.toLowerCase(); // Convertendo filtro para minúsculas
    const filmesFiltrados = this.state.filmesOriginais.filter((filme) =>
      filme.titulo.toLowerCase().includes(filtroMin) // Convertendo título para minúsculas
    );
    this.setState({ filmes: filmesFiltrados });
  };

  handleLimparFiltro = () => {
    this.setState({ filmes: this.state.filmesOriginais, filtro: '' });
  };

  handleInputChange = (event) => {
    this.setState({ filtro: event.target.value });
  };

  render() {
    return (
      <div className="container">
        <input
          type="text"
          placeholder="Filtrar por filmes"
          value={this.state.filtro}
          onChange={this.handleInputChange}
        />
        <button className="botao-filtrar" onClick={this.handleFiltrarFilmes}>
          Filtrar
        </button>

        <button className="botao-limpar-filtro" onClick={this.handleLimparFiltro}>
          Limpar Filtro
        </button>
        <table className='tabela'>
          <TabelaHead
            ordenarCrescente={this.handleOrdenarCrescente}
            ordenarDecrescente={this.handleOrdenarDecrescente}
          />
          <TabelaFoot qtdFilmes={this.state.filmes.length} />
          <TabelaBody
            filmes={this.state.filmes}
            removerLinha={this.handleRemoverLinha}
          />
        </table>
      </div>
    );
  }
}

export default App;
