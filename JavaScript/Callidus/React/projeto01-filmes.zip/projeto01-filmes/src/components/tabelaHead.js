import React from 'react';

const TabelaHead = (props) => (
  <thead>
    <tr>
      <th colSpan="6">Tabela de Filmes</th>
    </tr>
    <tr>
      <th>Capa</th>
      <th>Título</th>
      <th>Diretor</th>
      <th>Gênero</th>
      <th>Ano</th>
    </tr>
  </thead>
);

export default TabelaHead;
