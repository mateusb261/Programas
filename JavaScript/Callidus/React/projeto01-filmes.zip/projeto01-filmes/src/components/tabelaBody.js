import React from 'react';

const TabelaBody = (props) => {
  return (
    <tbody>
      {props.filmes.map((filme) => (
        <tr key={filme.id}>
          <td>
            <img src={filme.imagem} alt={filme.titulo} style={{ width: '100px', height: 'auto' }} />
          </td>
          <td>{filme.titulo}</td>
          <td>{filme.diretor}</td>
          <td>{filme.genero}</td>
          <td>{filme.ano}</td>
          <td>
            <button className='botao remover' onClick={() => props.removerLinha(filme.id)}>
              Assistir
            </button>
          </td>
        </tr>
      ))}
    </tbody>
  );
};

export default TabelaBody;
