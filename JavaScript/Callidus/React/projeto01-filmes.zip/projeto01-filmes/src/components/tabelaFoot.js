import React from 'react';

const TabelaFoot = (props) => (
  <tfoot>
    <tr>
      <td colSpan="6">Quantidade de filmes na tabela: {props.qtdFilmes}</td>
    </tr>
  </tfoot>
);

export default TabelaFoot;
