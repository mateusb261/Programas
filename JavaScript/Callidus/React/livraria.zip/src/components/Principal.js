import React from 'react'
import Home from './Home'

const Principal = () => {
  return (
    <main className='principal'>
        <Home/>
    </main>
  );
}

export default Principal
