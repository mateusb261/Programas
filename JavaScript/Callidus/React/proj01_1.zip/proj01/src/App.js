import React, {Component} from 'react'
import TabelaHead from "./components/TabelaHead"
import TabelaFoot from "./components/TabelaFoot"
import TabelaBody from "./components/TabelaBody"
import SearchBar from "./components/SearchBar"

class App extends Component{
  state = {
    filmes: []
  };

  componentDidMount(){
    fetch("/api/filmes.json")
    .then(response => response.json())
    .then(filmes => this.setState({filmes}))
    .catch(function(error){
      console.log("Erro na requisição");
    })
    .finally(function(){
      console.log("Sempre retorna");
    });
  }

  handleRemoveLinha = (id) => {
    const filmes = this.state.filmes.filter(l => l.id != id)
    this.setState({filmes});

  };

  handleOrdernarCrescente = (titulo) => {
    const filmes = this.state.filmes.sort((a,b) => a.titulo < b.titulo ? -1 : 0)
    this.setState({filmes})
  };

  handleOrdernarDecrescente = (titulo) => {
    const filmes = this.state.filmes.sort((a,b) => a.titulo < b.titulo ? -1 : 0)
    filmes.reverse();
    this.setState({filmes})
  };

  handlePesquisar = () => {
    let filmes = this.state.filmes
    let achado = 0;
    let titulo = document.getElementById("titulo").value;
    console.log(titulo);
    console.log(filmes[0].titulo.trim().toUpperCase());
    if (titulo.length != 0){
      for(let i=0; i < filmes.length; i++){
        if (filmes[i].titulo.toUpperCase() == titulo.toUpperCase()){
          console.log("Filme encontrado")
          const filmes = this.state.filmes.filter(l => l.titulo.toUpperCase() == titulo.toUpperCase())
          this.setState({filmes});
          achado = 1;
        }
      }
      if (achado == 0)
        window.alert("Não fora encontrado nenhum titulo");
    }
    else
      window.alert("Não fora inserido nenhum titulo");
  };

  render(){
    return (
      <table className='tabela'>
        <SearchBar
        pesquisar = {this.handlePesquisar}>  
        </SearchBar>
        <TabelaHead
        ordenarCrescente = {this.handleOrdernarCrescente}
        ordenarDecrescente = {this.handleOrdernarDecrescente}
        />
        <TabelaFoot qdeFilmes = {this.state.filmes.length}
        />
        <TabelaBody 
          filmes = {this.state.filmes}
          removerLinha = {this.handleRemoveLinha}
          />
          
      </table>
    );
  }
}

export default App;