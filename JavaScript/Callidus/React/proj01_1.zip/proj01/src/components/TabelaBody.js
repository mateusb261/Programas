import React from 'react'

const TabelaBody = (props) => (
    <tbody>
        {props.filmes.map((filme, index) => (
            <tr key={filme.id}>
                <td>{<img src= {filme.imagem}  width = "95" height= "144"/>}</td>
                <td>{filme.titulo}</td>
                <td>{filme.diretor}</td>
                <td>{filme.genero}</td>
                <td>{filme.duracao}</td>
            <td>
                <button className='botao remover'
                onClick={()=> props.removerLinha(filme.id)}
                >Remover</button>
            </td>
        </tr>
        ))}
    </tbody>
);

export default TabelaBody;