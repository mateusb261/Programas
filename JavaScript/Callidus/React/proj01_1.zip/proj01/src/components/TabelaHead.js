import React from 'react'

const TabelaHead = (props) => (
    <thead>
        <tr>
            <th colSpan="6">Tabela de filmes</th>
        </tr>
        <tr>
            <th>Imagem</th>
            <th>Título
                <div className='conteiner_setinhas'>
                    <div onClick={()=>props.ordenarCrescente()}> &#129093;</div>
                    <div onClick={()=>props.ordenarDecrescente()}>&#129095;</div>
                </div>
            </th>
            <th>Diretor(es)</th>
            <th>Gênero</th>
            <th>Duração</th>
            <th></th>
        </tr>
    </thead>
);

export default TabelaHead;