import React from 'react'

const SearchBar = (props) => (
    <div>
        <input type = "text" id = "titulo" placeholder='Insira o nome do filme'></input> 
        <tr></tr>
        <button className='pesquisar' onClick = {() => props.pesquisar()}> Pesquisar</button>
    </div>

)

export default SearchBar;