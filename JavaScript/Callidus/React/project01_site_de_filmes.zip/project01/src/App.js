import React, {Component} from 'react'
import TabelaHead from "./components/TabelaHead"
import TabelaFoot from "./components/TabelaFoot"
import TabelaBody from "./components/TabelaBody"
import { render } from '@testing-library/react'

class App extends Component{
  state = { 
    filmes: []
  };
  componentDidMount(){
    fetch("/api/filmes.json")
    .then(response => response.json())
    .then(filmes => this.setState({filmes}))
    .catch(function(error){
      console.log("Erro na requisição")
    })
    .finally(function(){
      console.log("sempre retorna")
    });
  }

  handleRemoveLinha = (id) =>{
    const filmes = this.state.filmes.filter(l => l.id !== id);
    this.setState({filmes});
  };
  
  handleOrdenarCrescente = (titulo) => {
    const filmes = this.state.filmes.sort((a,b) => a.titulo < b.titulo ? -1:0);
    this.setState({filmes});
  };
  
  handleOrdenarDecrescente = (titulo) => {
    const filmes = this.state.filmes.sort((a,b) => a.titulo < b.titulo ? -1:0);
    filmes.reverse();
    this.setState({filmes});
  };
  handlePesquisarFilme = () => {
    var titulo = document.getElementById("pesquisar").value
    const filmes = this.state.filmes.filter(t => t.titulo.toUpperCase() == titulo.toUpperCase());
    this.setState({ filmes});
  };
  
  
  render(){
    return(
      <table className='tabela'>
        <TabelaHead tabela = {this.state.filmes}
          ordenarCrescente = {this.handleOrdenarCrescente}
          ordenarDecrescente = {this.handleOrdenarDecrescente}
          pesquisafilme = {this.handlePesquisarFilme}
        />
        <TabelaFoot qdefilmes = {this.state.filmes.length}/>
        <TabelaBody filmes = {this.state.filmes} removeLinha = {this.handleRemoveLinha}/>
      </table>
    );
  }
}

export default App;
