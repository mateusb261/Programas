import React from 'react'

const TabelaFoot = props => (
    <tfoot>
        <tr>
            <td colSpan="7">Quantidade de filmes no site: {props.qdefilmes}</td>
        </tr>
    </tfoot>
);

export default TabelaFoot;
