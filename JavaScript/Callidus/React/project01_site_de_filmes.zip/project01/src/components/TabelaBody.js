import React from 'react'

const TabelaBody = props => (
    <tbody>
        {props.filmes.map((filmes, index) => (
            <tr key={filmes.id}>
                <td>{filmes.id}</td>
                <td>{filmes.titulo}</td>
                <td>{filmes.diretor}</td>
                <td>{filmes.gênero}</td>
                <td>{filmes.ano}</td>
                <td>
                    <button className='botao remover'onClick={() => props.removeLinha(filmes.id)}>Remover</button>
                </td>
            </tr>
        ))}
    </tbody>
);

export default TabelaBody;