import React from 'react'

const TabelaHead = props => (
    <thead>
        <tr>
            <th colSpan="7">Tabela de filmes</th>
        </tr>
        <tr>
            <td colSpan="7" align="center">
                <input type="text" id ="pesquisar"/> <button className='botao pesquisar'onClick={() => props.pesquisafilme()}>Pesquisar</button>
            </td>
        </tr>
        <tr>
            <th>ID</th>
            <th>Título</th>
            <th>Diretor</th>
            <th>Gênero</th>
            <th>Ano</th>
            <div className='container-setinhas'>
                <div onClick={()=>props.ordenarCrescente()}>&#129093;</div>
                <div onClick={()=>props.ordenarDecrescente()}>&#129095;</div>
            </div>
        </tr>
    </thead>
);

export default TabelaHead;