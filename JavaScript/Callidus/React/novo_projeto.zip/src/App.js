import React, { Component } from "react";
import TabelaHead from "./components/TabelaHead";
import TabelaFoot from "./components/TabelaFoot";
import TabelaBody from "./components/TabelaBody";
import "./index.css";

class App extends Component {
  state = {
    filmes: [],
    pesquisa: "",
  };

  componentDidMount() {
    // Fetch data and set it to the "filmes" state
    fetch("/api/filmes.json")
      .then((response) => response.json())
      .then((filmes) => this.setState({ filmes }))
      .catch(function (error) {
        console.log("Erro na requisição");
      })
      .finally(function () {
        console.log("Sempre retorna");
      });
  }

  handleRemoveLinha = (id) => {
    const filmes = this.state.filmes.filter((f) => f.id !== id);
    this.setState({ filmes });
  };

  handleOrdenarCrescente = () => {
    const filmes = this.state.filmes.sort((a, b) =>
      a.titulo < b.titulo ? -1 : 0
    );
    this.setState({ filmes });
  };

  handleOrdenarDecrescente = () => {
    const filmes = this.state.filmes.sort((a, b) =>
      a.titulo > b.titulo ? -1 : 0
    );
    this.setState({ filmes });
  };

  handlePesquisa = (valorPesquisa) => {
    this.setState({ pesquisa: valorPesquisa });
  };

  render() {
    const filmesFiltrados = this.state.filmes.filter((filme) =>
      filme.titulo.toLowerCase().includes(this.state.pesquisa.toLowerCase())
    );

    return (
      <table className="tabela">
        <TabelaHead
          ordenarCrescente={this.handleOrdenarCrescente}
          ordenarDecrescente={this.handleOrdenarDecrescente}
          onPesquisaChange={this.handlePesquisa}
        />
        <TabelaBody filmes={filmesFiltrados} removerLinha={this.handleRemoveLinha} />
        <TabelaFoot qdeFilmes={filmesFiltrados.length} />
      </table>
    );
  }
}

export default App;
