import React from "react";

const TabelaHead = (props) => (
    <thead>
      <tr>
        <th colSpan="5">TABELA DE FILMES</th>
      </tr>

      <tr>
      <th colSpan="5">
        <input
          type="text"
          placeholder="Pesquisar..."
          onChange={(e) => props.onPesquisaChange(e.target.value)}
        />
      </th>
      </tr>

      <tr>
        <th>TÍTULO
          <div className='container-setinhas'>
            <div onClick={() => props.ordenarCrescente()}>&#129093;</div>
            <div onClick={() => props.ordenarDecrescente()}>&#129095;</div>
          </div>
        </th>
        <th>DIRETOR</th>
        <th>GÊNERO</th>
        <th>ANO</th>
        <th></th>
      </tr>
    </thead>
  );

export default TabelaHead;
