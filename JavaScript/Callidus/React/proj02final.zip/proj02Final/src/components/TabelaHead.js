import React from 'react'

const TabelaHead = (props) => (
    <thead>
        <tr style={{background: 'none'}}>
        
        <th>
            <input style={{width: 200, border: 'none', background: 'none'}} type='text' placeholder='Procure um filme...' className='filtrar filme'value={props.valor} onChange={props.handleChange} />
        </th>
        <th>
            <button onClick={() => props.filtrarFilme(props.valor)} className='botão busca'> 🔎 </button>
        </th>
        </tr> 
        
    </thead>
);

export default TabelaHead;