import React from 'react'

const TabelaFoot = (props) => (
    <tfoot>
        <tr>
        </tr>
    </tfoot>
);

export default TabelaFoot;