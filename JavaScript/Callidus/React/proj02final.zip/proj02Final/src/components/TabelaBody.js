import React from 'react'

const TabelaBody = (props) => (
    <tbody>
        {props.livros.map((livro, index) => (
            <tr key={livro.id} style={{}}>
                
                <td> <img src={`${process.env.PUBLIC_URL}/${livro.img}`} alt={livro.titulo} style={{ width: 262, height: 388}}></img>      
                    <p style={{ textAlign: 'left' }}> {livro.titulo} </p>


                </td>
                <td style={{ textAlign: 'left', verticalAlign: 'up', width: 2000}}>
                    {/*style={{ textAlign: 'left' }}>*/}
                    <p> 🎬 Gênero: {livro.genero} </p>
                    <p> 🎥 Diretor: {livro.diretor} </p>
                    <p> 📆 Ano: {livro.ano} </p>
                </td>

                <td> <p style={{ textAlign: 'justify', fontSize: 20, width:500 }}> Sinopse: {livro.snp}</p> </td>
                <td></td>
                <td></td>
                <td></td>
    

                {/*<td>
                <button className='botao remover' 
                    onClick={()=> props.removerLinha(livro.id)}
                    id = {livro.id}
                > Remover </button>
                </td>*/}

        </tr>
        ))}
    </tbody>
);

export default TabelaBody;