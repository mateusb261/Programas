import React, {Component} from 'react'
import TabelaHead from "./components/TabelaHead"
import TabelaFoot from "./components/TabelaFoot"
import TabelaBody from "./components/TabelaBody"

class App extends Component{
  state = {
    livros: [],
    valor: ''
  };

  componentDidMount(){
    fetch("/api/livros.json")
      .then(response => response.json())
      .then(livros => this.setState({livros}))
      .catch(function(error){
        console.log("Erro na requisição");
      })
      .finally(function(){
        console.log("Sempre retorna");
      });
  }

  handleFiltrar = (valor) => {
    const livros = this.state.livros.filter(filme => filme.titulo === valor);
    this.setState({livros});
  };

  handleChange = (event) => {
    this.setState({ valor: event.target.value})
  }

  render(){
    return (
      <table className='tabela'>
        <TabelaHead
            filtrarFilme = {this.handleFiltrar}
            valor = {this.state.valor}
            handleChange = {this.handleChange}
        />
        <TabelaFoot qdeLivros = {this.state.livros.length}/>
        <TabelaBody 
            livros = {this.state.livros}
        />
      </table>
    );
  }
}

export default App;